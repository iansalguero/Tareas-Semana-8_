namespace T8__JJSC_1202022
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnBase2_Click(object sender, EventArgs e)
        {
            int n1 = int.Parse(txtNum1.Text);
            int n2 = n1;
            string binario = "";
            if (n2 > 0)
            {
                while (n2 > 0)
                {
                    if (n2 % 2 == 0)
                    {
                        binario = "0" + binario;
                    }
                    else
                    {
                        binario = "1" + binario;
                    }
                    n2 = (int)n2 / 2;
                }
            }
            else if (n2 == 0)
            {
                binario = "0";
            }
            else
            {
                binario = "ERROR, ingrese solo numeros positivos.";
            }
            lblRes1.Text = "El n�mero decimal es: " + n1 + " , a binario es: " + binario;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n2 = int.Parse(txtNum2.Text);
            lblRes2.Text = "El n�mero decimal es: " + n2 + " , a hexadecimal es: " + Decimal_Hexadecimal(n2);
        }

        public static string Decimal_Hexadecimal(int numero)
        {

            if (numero < 1)
            {
                return "0";
            }

            int hexadecimal = numero;
            string resultado = "";

            while (numero > 0)
            {
                hexadecimal = numero % 16;

                if (hexadecimal < 10)
                {
                    resultado = resultado.Insert(0, Convert.ToChar(hexadecimal + 48).ToString());
                }
                else
                {
                    resultado = resultado.Insert(0, Convert.ToChar(hexadecimal + 55).ToString());
                }

                numero = numero / 16;
            }

            return resultado;
        }


    }
}