namespace prueba
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            double n1;
            double res = 0;
            try
            {
                n1 = double.Parse(textBox1.Text);

                double m = 1;
                double resultado_a;
                do
                {
                    resultado_a = 1 / m;
                    res = resultado_a + res;
                    m++;
                }
                while (m <= n1);
                label1.Text = "El resultado es " + res;
            }
            catch
            {
                MessageBox.Show("N�mero ingresado no es v�lido", "Error");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                    double n2 = double.Parse(textBox2.Text);

                    double m = 1, res = 0;
                    double resultado_a;
                    do
                    {
                        resultado_a = 1 / Math.Pow(2,m);
                        res = resultado_a + res;
                        m++;
                    }
                    while (m <= n2);
                    label4.Text = "El resultado es " + res;
            }
            catch
            {
                MessageBox.Show("El n�mero ingresado no es correcto", "Error");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {


                int k = 0;
                double res = 0;
                double x = double.Parse(textBox3.Text);
                double a = double.Parse(textBox4.Text);
                double n = double.Parse(textBox5.Text);
                do
                {
                  
                    double resultado = Math.Pow(x, k) * Math.Pow(a, n-k); 
                    res = resultado + res;
                    k++;
                }
                while (k <= n);
                label9.Text = "El resultado es " + res;
            }
            catch
            {
                MessageBox.Show("Los n�meros ingresados no son correctos", "Error");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
 
        }
    }
}